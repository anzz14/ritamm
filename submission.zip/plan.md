# GPF Quarter-Close — Build Guide (Node 24 · TypeScript · Two A2A Agents)
> One module at a time. Build → Test → Commit → Next. Never skip a test checkpoint.

**Stack (pinned, verified to install/run):** Node 24 · TypeScript `~5.9` · `tsx` (runner) · Express 5 · zod 4 · decimal.js 10.6 · pdfjs-dist 6.4 (legacy build) · exceljs 4.4 · dotenv · vitest 5
**Not used:** Python. (The brief says "Python 3.11+" and shows `python main.py ./pack .` — we are pure Node. You are emailing Ritamm; see Step 0.)
**Principles:** Pure functions in `core/`, I/O at the edges, agents are thin. SOLID, DRY, no hardcoded company names or amounts anywhere in `src/` (graders may run a variant pack). All money = decimal.js / integer cents, never JS floats.

---

## 
LLM_API_KEY=<your OPENROUTER key>
LLM_BASE_URL=https://openrouter.ai/api/v1
LLM_MODEL=openai/gpt-oss-20b:free
AGENT_A_PORT=8001
AGENT_B_PORT=8002
```
OpenRouter **is** OpenAI-compatible, so it works. But the code must read ONLY `LLM_API_KEY / LLM_BASE_URL / LLM_MODEL` (graders set those, likely Groq). Never read `OPENROUTER_API_KEY`, never add OpenRouter-only request params.

---

## Locked decisions (from your answers)

| Topic | Decision |
|---|---|
| Run command | Pure Node: `npm start -- ./pack .` (no main.py). README documents it. |
| A2A | Hand-rolled on Express 5 + zod, shared `src/a2a/` module. (Official `@a2a-js/sdk` latest is 1.x; the brief pins A2A **0.3** with `kind` fields — avoids a version mismatch.) |
| R1 threshold | **15 %**, absolute change measured in the company's **local currency** (EUR move ≠ value change). |
| LLM failure | Retry (backoff) → then **rules fallback**, every row tagged `categorized_by: "llm" \| "rules_fallback"`, disclosed in README. |
| Money | `decimal.js` everywhere. Output JSON numbers via `.toDecimalPlaces(2).toNumber()`. |
| FX | EUR/USD **1.0666** = ECB reference rate for **30 Dec 2022** (last published rate on/before Sat 31 Dec; same convention CVP used in Q3: 30 Sep 2022 → 0.9748). Stored in `config/fx-rates.json` with source URL; never fetched at runtime. Source: https://www.ecb.europa.eu/stats/exchange/eurofxref/shared/pdf/2022/12/20221230.pdf — **open it yourself and confirm before you submit.** |

---

## Ground truth I verified (use as golden test fixtures)

Bank PDF parsed in a Node prototype: **39 transactions** (excluding "BALANCE BROUGHT FORWARD"), balance chain 0 breaks, debits 38,016,350.00, credits 49,462,929.25 (both match the PDF's own TOTAL line), closing 23,896,579.25.

| Output | Expected |
|---|---|
| closing_cash | 23,896,579.25 |
| capital_called | 20,000,000.00 (10 LPs × 8 % of commitment; LP07 paid in 2 wires; LP10 wire has **no LP code**) |
| distributions | 22,500,000.00 (10 wires × 9 %) |
| income | 459,429.25 (dividend 420,000 + interest 39,429.25) |
| management_fee | 1,250,000.00 |
| expenses (total) | 1,522,850.00 = fee 1,250,000 + legal 38,500 − refund 3,500 + D&O 42,000 + bank charges 850 + Q4 accruals 195,000 |
| realized_gain | 9,000,000.00 (Fjord 29,000,000 − cost 20,000,000) |
| investments_usd | 146,062,460.00 (Ember 13,100,000 × 1.0666 = 13,972,460; Ionmere at cost 14,000,000) |
| liabilities | 195,000.00 |
| unrealized Q3 → Q4 | 23,775,800 → 27,878,460; change 4,102,660.00 |
| **nav_q3** | 160,224,800.00 |
| **nav_q4** | **169,764,039.25** (bridge difference 0.00) |

Review expected at 15 %: R1 → Bluetarn (+37.5 %), Cedar (−31.9 %), Harbor (+17.8 %); R2 → Delta (Recent transaction → Market multiples); R3 → Ionmere (carry at cost); R4 → none; Ember −2.96 % local (USD +6.17 % is FX, **not** flagged); Fjord sold, not in NAV.

## Traps in the data (each has a test later)
1. Descriptions wrap over 2–3 lines; page 2 repeats the header; footer + TOTAL line must not become transactions.
2. Debit/credit columns are right-aligned **under/after** their header labels — assign numeric tokens by header *left* edges, not nearest right edge (my first prototype got this wrong).
3. LP10 capital call (09 Nov, "R MEHTA FAM TRST … CALL NO 7") has no LP code → resolve from the LP roster in the Q3 NAV file.
4. Sale line payer is *Nordic Acquisitions*; the company sold is **Fjord Payments AS**.
5. "MISC CREDIT … REFUND" = `expense_refund`, not income. D&O premium for 2023 is still a Q4 expense.
6. Harbourside 65,000 and Coral & Finch 120,000 = `accrual_settlement` (NOT expenses).
7. `agent_b_data.json` amounts are **strings**; Agent A sends numbers. Compare in cents.
8. exceljs returns formula cells as `{formula,result}` and dates as UTC `Date` — unwrap `.result`, use UTC/ISO slicing.
9. Total rows are not data. Ignore them, recompute, assert Q3: cash + investments − liabilities = 160,224,800.

---

## Module order

| # | Module | Build | Test |
|---|---|---|---|
| 0 | Scaffold | package.json, tsconfig, vitest, lint, folders | `npm run typecheck && npm test` green (0 tests ok) |
| 1 | Core primitives | money, dates, errors, logger, config | unit tests |
| 2 | A2A layer | schemas, server factory, client, jsonl log | unit + local echo agent |
| 3 | Pack loaders | xlsx/json → typed domain | unit tests vs real pack |
| 4 | Bank PDF parser | pdfjs rows → raw transactions | golden: 39 rows |
| 5 | Bank checks | balance chain, totals | unit incl. tamper tests |
| 6 | LLM client | OpenAI-compatible, retry, cache | mocked-fetch tests |
| 7 | Categorizer | prompt, schema, validators, fallback | golden labels (offline) |
| 8 | Trades derivation + Agent A | purchases/sales, A2A executor | endpoint tests |
| 9 | Review engine | R1–R4 | unit tests |
| 10 | NAV engine | NAV + bridge | golden numbers |
| 11 | Agent B | two-turn state machine | endpoint tests |
| 12 | Orchestrator + outputs | main.ts, output files | end-to-end offline |
| 13 | Smoke script | endpoint health table | `npm run smoke` |
| 14 | Docs + package | README, ASSUMPTIONS, DECISIONS, zip | dry run from clean clone |

## Repo layout (target)
```
src/
  main.ts                 # orchestrator (one command)
  config/{env.ts,fx.ts}
  core/{money.ts,dates.ts,errors.ts,logger.ts,types.ts}
  a2a/{schemas.ts,server.ts,client.ts,log.ts}
  pack/{loadCvpQ3.ts,loadNavSummary.ts,loadAgentBData.ts}
  agentA/{index.ts,executor.ts,pdf/{extractRows.ts,parseStatement.ts},checks.ts,
          llm/{client.ts,prompt.ts,categorize.ts,fallback.ts,validate.ts},trades.ts}
  agentB/{index.ts,executor.ts,verifyTrades.ts,review.ts,nav.ts,marks.ts}
  output/writers.ts
config/fx-rates.json
tests/{unit,integration,fixtures}
scripts/{smoke.ts,llm-live-check.ts}
```

## Paste this block at the top of EVERY prompt
```
CONVENTIONS (apply to all code you write):
- Node 24, TypeScript strict, ESM ("type":"module"), imports use .js suffix per TS ESM rules, run via tsx.
- Pure functions in core/; side effects (fs, http, LLM) only in edge modules. Inject dependencies (fetch, clock, fs) so tests run offline.
- Max ~120 lines per file, one responsibility per file. No duplication: reuse core/money.ts, core/dates.ts.
- Money is decimal.js only. Never parseFloat/Number for arithmetic. No hardcoded company names/amounts/dates in src/.
- Validate every external boundary (files, HTTP, LLM output) with zod. Throw typed errors from core/errors.ts.
- Write vitest tests for what you build, in tests/unit or tests/integration. Tests must be offline.
- After coding: run `npm run typecheck && npm test`, fix failures, and report exactly what passes.
- Do not add dependencies beyond: express zod decimal.js pdfjs-dist exceljs dotenv (dev: typescript tsx vitest @types/node @types/express).
```

---

## MODULE 0 — Scaffold
> Goal: empty project that type-checks and runs vitest.

### PROMPT 0-A — Project files
```
[paste CONVENTIONS]

Create a Node project "gpf-quarter-close" in the current folder.

package.json: "type":"module", "engines":{"node":">=22.13"}, scripts:
  "start": "tsx src/main.ts",
  "test": "vitest run",
  "typecheck": "tsc --noEmit",
  "smoke": "tsx scripts/smoke.ts",
  "llm:check": "tsx scripts/llm-live-check.ts"
dependencies (runtime, INCLUDING tsx so `npm install` is enough for graders):
  express@^5 zod@^4 decimal.js@^10.6 pdfjs-dist@6.4.299 exceljs@4.4.0 dotenv tsx
devDependencies: typescript@~5.9.3 vitest @types/node @types/express

tsconfig.json: target ES2023, module NodeNext, moduleResolution NodeNext, strict, noUncheckedIndexedAccess,
  esModuleInterop, skipLibCheck, noEmit, include ["src","tests","scripts"].
vitest.config.ts: environment node, include tests/**/*.test.ts.
.gitignore: node_modules, .env, output/ is NOT ignored (we submit it), .cache/, *.log, .DS_Store.
.env.example: copy EXACTLY the variables from the pack's env.example (LLM_API_KEY, LLM_BASE_URL, LLM_MODEL,
AGENT_A_PORT, AGENT_B_PORT, PACK_DIR) with comments.
Create the empty folders from the repo layout with .gitkeep. Create pack/ and copy the provided input files into it
(statement PDF, both xlsx, agent_b_data.json, templates).
Add one trivial test tests/unit/sanity.test.ts so vitest has something to run.
```
### ✅ MODULE 0 TEST
```bash
npm install && npm run typecheck && npm test
# Expected: tsc silent, 1 test passed
```

---

## MODULE 1 — Core primitives
> Goal: money, dates, errors, logger, config — everything else builds on these.

### PROMPT 1-A — money.ts
```
[paste CONVENTIONS]

Write src/core/money.ts (decimal.js, ROUND_HALF_UP configured on a cloned Decimal constructor so we never mutate global config).
Export:
- type Money = Decimal
- parseMoney(input: string | number): Money — strips commas and spaces, rejects NaN/empty/more than 2dp for bank amounts via parseBankAmount, but parseMoney itself accepts any decimal string (marks may be "13100000").
- parseBankAmount(s: string): Money — requires /^-?[\d,]+\.\d{2}$/ else throw ParseError.
- toCents(m: Money): bigint ; fromCents(c: bigint): Money
- round2(m): Money (half-up) ; toNumber2(m): number  (= round2(m).toNumber(), used for JSON output)
- sum(ms: Money[]): Money ; eq(a,b): boolean (compare at 2dp)
- mulRate(amount: Money, rate: string): Money — exact decimal multiply then round2.
- pctChange(from: Money, to: Money): Decimal — (to-from)/from*100, throws if from is 0.
Tests (tests/unit/money.test.ts): 13,100,000 × "1.0666" = 13,972,460.00; 0.1+0.2 style sums exact; parseBankAmount rejects "1,2.5"; pctChange(24.6M, 25.7M) ≈ 4.47; toNumber2 of 8150.27+21402.88+9876.10 = 39429.25.
```
### PROMPT 1-B — dates, errors, logger
```
[paste CONVENTIONS]

1) src/core/dates.ts
- parseStatementDate("03 Oct 2022") -> "2022-10-03" (pure string/month-map parsing, NO Date objects, NO timezone dependence).
- isoFromUtcDate(d: Date) -> "YYYY-MM-DD" using UTC getters (exceljs returns UTC midnight).
- isIsoDate(s) type guard.
2) src/core/errors.ts — class AppError(code, message, details?) and subclasses ParseError, ValidationError, ReconciliationError, LlmError, A2AError(code number for JSON-RPC).
3) src/core/logger.ts — tiny logger: log.info/warn/error(msg, ctx?) writing single-line JSON to stderr with ts+level; level from LOG_LEVEL env. Never log secrets (redact keys named /key|token|secret/i).
Tests: date parsing for every month; invalid month throws ParseError; UTC date helper does not shift day.
```
### PROMPT 1-C — config
```
[paste CONVENTIONS]

Write src/config/env.ts: loads dotenv (quiet), then zod-validates:
 LLM_API_KEY (string, optional at load — required only when Agent A runs the LLM), LLM_BASE_URL (url), LLM_MODEL (string),
 AGENT_A_PORT default 8001, AGENT_B_PORT default 8002 (coerce number), PACK_DIR default "./pack", OUTPUT_DIR default "./output",
 THRESHOLD_PCT default "15", LLM_CACHE_DIR optional.
Export getEnv(overrides?) so tests can inject. Fail with a readable message listing missing/invalid vars (never print values of secrets).
Write src/config/fx.ts + config/fx-rates.json:
 {"EUR/USD":{"rate":"1.0666","rate_date":"2022-12-30","valuation_date":"2022-12-31","source":"https://www.ecb.europa.eu/stats/exchange/eurofxref/shared/pdf/2022/12/20221230.pdf","note":"31 Dec 2022 was a Saturday; last published ECB rate on/before the valuation date"}}
 loadFx(path) validates with zod and returns {rate: string, rateDate, source}. Rate stays a STRING.
Tests: defaults applied, bad port rejected, fx file validated.
```
### ✅ MODULE 1 TEST
```bash
npm run typecheck && npm test
# All money/date/env/fx tests pass. Eyeball: 13,100,000 × 1.0666 = 13972460.00
```

---

## MODULE 2 — A2A layer (shared by both agents)
> Goal: tiny, reusable JSON-RPC 2.0 A2A 0.3 server + client + logging. Proven with a toy agent before real agents exist.

### PROMPT 2-A — Schemas
```
[paste CONVENTIONS]

Write src/a2a/schemas.ts (zod 4) for A2A 0.3 subset we need:
- Part = {kind:"text",text} | {kind:"data",data: Record<string,unknown>}
- Message = {kind:"message", role:"user"|"agent", messageId, parts: Part[], taskId?, contextId?}
- TaskState "submitted"|"working"|"input-required"|"completed"|"failed"|"canceled"
- Task = {kind:"task", id, contextId, status:{state, message?, timestamp}, artifacts?:[{artifactId,name?,parts:Part[]}], history?}
- JsonRpcRequest {jsonrpc:"2.0", id: string|number|null, method, params}; response result/error shapes.
- AgentCard {protocolVersion:"0.3.0", name, description, url, preferredTransport:"JSONRPC", version, capabilities:{streaming:false,pushNotifications:false}, defaultInputModes:["application/json","text/plain"], defaultOutputModes:["application/json"], skills:[{id,name,description,tags}]}
- MessageSendParams {message: Message}
Export inferred types. Export JSON-RPC error codes: ParseError -32700, InvalidRequest -32600, MethodNotFound -32601, InvalidParams -32602, InternalError -32603, TaskNotFound -32001.
Tests: valid sample from the brief parses; missing messageId rejected.
```
### PROMPT 2-B — Server factory
```
[paste CONVENTIONS]

Write src/a2a/server.ts: createA2AServer({card, handler, logger, logSink?}) returning an Express 5 app (not listening).
- GET /.well-known/agent-card.json -> card.
- POST /  (the card's url path) accepts JSON-RPC. Rules:
  * malformed JSON -> HTTP 200 body {jsonrpc,id:null,error:-32700}
  * invalid envelope -> -32600 ; method != "message/send" -> -32601 ; params fail zod -> -32602
  * call handler(message, ctx) where handler: (msg: Message) => Promise<Task>; wrap thrown errors into -32603 (never leak stack traces).
- Interface AgentHandler { handleMessage(msg): Promise<Task> } so Agent A/B just implement it (Dependency Inversion).
- Provide InMemoryTaskStore {get,set} class in src/a2a/taskStore.ts (Map-based) used by handlers.
- Every request and response goes to logSink (see 2-D).
- helper makeTask(state, parts, {id?,contextId?}) and helper textPart/dataPart in src/a2a/builders.ts.
- helper startServer(app, port): Promise<{close():Promise<void>, port:number}> supporting port 0 (ephemeral) for tests.
```
### PROMPT 2-C — Client
```
[paste CONVENTIONS]

Write src/a2a/client.ts: class A2AClient { constructor(baseUrl, {fetchImpl=fetch, logSink?, timeoutMs=30000}) }
- async getCard(): GET /.well-known/agent-card.json, zod-validate, remember card.url.
- async sendMessage(message): POST JSON-RPC message/send to card.url, validate response with zod, throw A2AError on JSON-RPC error, return Task.
- uses AbortSignal.timeout. uuid via crypto.randomUUID().
- helper buildUserMessage(parts, {taskId?, contextId?}).
```
### PROMPT 2-D — jsonl log
```
[paste CONVENTIONS]

Write src/a2a/log.ts: createJsonlLog(filePath) -> {write(entry)}, entry = {ts: ISO string, direction:"request"|"response", from, to, payload}. Appends one JSON line per call (fs.appendFileSync is fine; create dir). Provide createMemoryLog() for tests.
The client AND server both write to the SAME file path in the orchestrator, but to avoid doubles: the CLIENT logs request+response (that is the "between your two agents" record). The server logging is optional debug only via logger.
```
### PROMPT 2-E — Toy agent proof
```
[paste CONVENTIONS]

Write tests/integration/a2a.echo.test.ts: spin up a toy handler on port 0 that replies input-required then completed on a second message with the same taskId/contextId. Assert: card served; happy 2-turn flow through A2AClient; -32700/-32600/-32601/-32602 paths; log has 4 entries (2 requests, 2 responses) with timestamps.
```
### ✅ MODULE 2 TEST
```bash
npm test -- a2a
# All echo-agent tests pass. This proves the protocol layer before any finance code exists.
```

---

## MODULE 3 — Pack loaders
> Goal: typed domain objects from the real input files.

### PROMPT 3-A — Types + Q3 loaders
```
[paste CONVENTIONS]

Write src/core/types.ts: domain types using Money (decimal): Mark{company,currency,fairValue,method,valuationDate}, Q3Position{company,currency,costLocal,fairValueLocal,fxRate,fairValueUsd,method}, Q3Holding{company,costUsd,fairValueUsd}, Liability{name,amount}, LpCommitment{code,name,commitment}.

Write src/pack/loadCvpQ3.ts (exceljs): reads "CVP_Valuation_Report_Q3_2022.xlsx", header row detected by finding cell "Portfolio company" (don't hardcode row numbers), reads rows until the "Total" row. Unwrap cells: if value is object with .result use that; dates via isoFromUtcDate. Return Q3Position[].
Write src/pack/loadNavSummary.ts: sheet 1 -> {cash, investmentsFv, liabilities: Liability[], navQ3, holdings: Q3Holding[], lps: LpCommitment[]}; sheet 2 -> q4Accruals: Liability[]. Find sections by label text ("Total liabilities", "Investor (LP)"), not fixed coordinates. Do NOT trust total cells: recompute and assert cash + Σ holdings FV − Σ liabilities == navQ3 else throw ReconciliationError.
File names resolved by pattern (glob-ish by readdir: /CVP_Valuation_Report/, /GPF_NAV_Summary/) so renamed packs still load.
Tests (tests/unit/pack.test.ts, use the real files copied to tests/fixtures/pack): 8 Q3 positions; Ember fx "0.9748"; navQ3 160,224,800; 10 LPs; commitments sum 250,000,000; accruals total 195,000; Q3 holdings Σ FV 147,959,800.
```
### PROMPT 3-B — agent_b_data loader
```
[paste CONVENTIONS]

Write src/pack/loadAgentBData.ts: zod schema for agent_b_data.json (strings OR numbers for amounts, preprocess to Money). Returns {fundName, fundCode, valuationDate, marks, notes, purchases, sales}. This module is used ONLY by Agent B (Agent A must never import it — add an ESLint-free guard test that greps src/agentA for "agent_b_data" and fails).
Tests: 7 marks, 2 notes, purchases[0].amount 14,000,000, sales[0].proceeds 29,000,000.
```
### ✅ MODULE 3 TEST
```bash
npm test -- pack
```

---

## MODULE 4 — Bank PDF parser (Agent A)
> Goal: deterministic, LLM-free extraction of 39 raw rows. The riskiest module — test it hardest.

### PROMPT 4-A — Positioned text extraction
```
[paste CONVENTIONS]

Write src/agentA/pdf/extractRows.ts using pdfjs-dist LEGACY build:
  import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs"
getDocument({ data: new Uint8Array(buffer), useSystemFonts: true, verbosity: 0 }). For each page: getTextContent(), keep items with non-empty trimmed text as {s, x: transform[4], y: transform[5], r: x + width}.
Group into visual lines: sort by y desc then x asc; same line if |dy| <= 2. Return Page[] = {lines: {y, items[]}[]} (items sorted by x).
Pure + small. No finance logic here. Export extractLines(buffer): Promise<Page[]>.
Test with the real PDF: 2 pages; page 1 has a line containing items "Date","Description","Reference","Debit","Credit","Balance".
```
### PROMPT 4-B — Statement parser
```
[paste CONVENTIONS]

Write src/agentA/pdf/parseStatement.ts: parseStatement(pages): {opening: Money, rawRows: RawRow[], statedTotals?: {debits, credits}}.
RawRow = {date (ISO), description, reference, debit: Money, credit: Money, balance: Money}.

Algorithm (this exact approach was prototyped and worked on the real file):
1. Per page, find the header line (contains items "Date" and "Balance"). Record header x-LEFT edges for Description, Reference, Debit, Credit, Balance.
2. Numeric token = matches /^-?[\d,]+\.\d{2}$/. Assign it to a column by its RIGHT edge: the LAST column among [debit, credit, balance] whose header left edge <= token.r + 1. (Do NOT use nearest-header-right-edge: numbers are right-aligned past the header label and that mis-assigns debits to credit.)
3. Per line below the header: date text = items with x < descriptionLeft-2 joined; description = non-numeric items with x in [descLeft-2, refLeft-2); reference = non-numeric items with x in [refLeft-2, debitLeft-2).
4. A line whose date text matches /^\d{2} [A-Z][a-z]{2} \d{4}$/ starts a new row; a line without date is a CONTINUATION: append description (space-joined) and any reference text to the current row.
5. Stop a page at a line matching /TOTAL DEBITS/ (capture the two stated totals) or /Page \d+ of \d+/ (footer). Footers/disclaimers must never be appended to a row.
6. The "BALANCE BROUGHT FORWARD" row yields `opening` and is excluded from rawRows.
7. Normalise whitespace; keep description text as in the statement (uppercase is fine).
Edge cases: wrapped lines that are only "8.1" style tokens (not money — money requires 2 decimals); a row with neither debit nor credit -> ParseError; both set -> ParseError.
Header positions are re-derived per page (don't assume page 2 equals page 1).
No company/LP names anywhere in this file.
Tests (tests/unit/parseStatement.test.ts, real PDF): 39 rows; row[0] = 2022-10-03 debit 1,250,000.00 ref OW-221003-01 desc ends "PER LPA 8.1"; row for 09 Nov has credit 800,000.00 and desc contains "CALL NO 7"; last row 2022-12-30 debit 50.00; opening 12,450,000.00; statedTotals 38,016,350.00 / 49,462,929.25; no row description contains "Meridian" or "fictional".
```
### ✅ MODULE 4 TEST
```bash
npm test -- parseStatement
# 39 rows. If a debit lands in credit, fix the column rule (step 2) — don't patch amounts.
```

---

## MODULE 5 — Bank checks (code, not LLM)
### PROMPT 5-A — checks.ts
```
[paste CONVENTIONS]

Write src/agentA/checks.ts: runBankChecks(parsed): BankCheckReport, pure.
Checks (each returns {name, passed, detail}):
 1. running balance: for each row prev − debit + credit == balance (compare in cents); list ALL failing rows with index + date.
 2. opening + Σcredits − Σdebits == closing (last row balance).
 3. Σdebits and Σcredits equal the statement's stated totals (if present).
 4. every row has exactly one of debit/credit > 0.
Report = {opening, closing, totalDebits, totalCredits, transactionCount, checks[], passed}. assertBankChecks(report) throws ReconciliationError with the failing details.
Tests: real file passes; mutate a balance by 0.01 -> check 1 fails naming the row; drop a row -> check 2 fails; flip stated total -> check 3 fails.
Orchestrator later writes this report to output/bank_checks.json (extra file; transactions.json stays a pure list).
```
### ✅ MODULE 5 TEST
```bash
npm test -- checks
```

---

## MODULE 6 — LLM client
> Goal: generic OpenAI-compatible chat client with retry, JSON extraction, optional dev cache. Provider-agnostic.

### PROMPT 6-A — client
```
[paste CONVENTIONS]

Write src/agentA/llm/client.ts: class LlmClient({apiKey, baseUrl, model, fetchImpl=fetch, sleep, cacheDir?, maxRetries=4}).
chatJson(messages, zodSchema): Promise<T>
- POST `${baseUrl}/chat/completions` body {model, messages, temperature: 0, max_tokens: 4096}. Do NOT send response_format or provider-specific params (not all free models support them). Header Authorization: Bearer <key>. Never log the key.
- Content may be null/empty (reasoning models) -> treat as retryable LlmError.
- Extract JSON from content tolerant of ```json fences and leading prose (find first '[' or '{' to last matching bracket), JSON.parse, validate with zod. On validation failure retry ONCE with the zod error appended as a user message ("Your JSON failed validation: ... Return corrected JSON only").
- Retry on 429/5xx/network with exponential backoff + jitter, honour Retry-After header, max 4 attempts. 401/400 -> no retry, throw LlmError with status (no body secrets).
- Optional disk cache (dev only): key = sha256(model + JSON(messages)), file in cacheDir. Off unless LLM_CACHE_DIR set. Add .cache/ to gitignore.
Tests (mocked fetch only): fenced JSON parses; 429 then 200 succeeds and slept; 401 not retried; null content retried; invalid JSON then corrected JSON succeeds; cache hit makes zero fetches.
```
### ✅ MODULE 6 TEST
```bash
npm test -- llm/client
# Optional live ping (uses your key, costs 1 request):
npx tsx -e "import('./src/agentA/llm/client.js')" # then use scripts/llm-live-check.ts in Module 7
```

---

## MODULE 7 — Categorizer
> Goal: LLM categorizes; code validates; fallback guarantees completion.

### PROMPT 7-A — Prompt + schema
```
[paste CONVENTIONS]

Write src/agentA/llm/prompt.ts and src/agentA/llm/validate.ts.
Constants: CATEGORIES = capital_call, distribution, management_fee, investment_purchase, sale_proceeds, dividend_income, interest_income, bank_charges, expense, expense_refund, accrual_settlement.
LLM output schema (zod): array of {index:number, category: enum, lp_code: string|null, company: string|null, reason: short string}.
System prompt must contain: role; definition of each category with disambiguation rules:
 - capital_call: credit from an LP; distribution: debit to an LP.
 - sale_proceeds: credit from sale of a portfolio company; company = the company SOLD, not the buyer/payer.
 - investment_purchase: debit subscribing for shares; company = the company bought.
 - expense_refund: credit refunding a previously paid expense (words REFUND/OVERBILLING), NOT income.
 - accrual_settlement: payment of an invoice for a PRIOR-period service already accrued (e.g. admin services or audit for a past period/year) — pass the list of Q3 liabilities (names+amounts) in the prompt as context; mark a payment as accrual_settlement only if description AND amount match one of them.
 - management_fee: fee to the fund's manager/adviser per LPA. bank_charges: bank's own fees (maintenance, wire charges). expense: all other operating payments (legal, insurance premium even for a later period).
 - lp_code: only for capital_call/distribution; use the LP roster (code ↔ name) passed in the prompt; if the description names an LP without code, match to the roster; else null.
 - company: only for investment_purchase/sale_proceeds, in normal casing (Title Case with legal suffix), else null.
 Output ONLY JSON array. Include 3 few-shot examples built from DIFFERENT wording than the real rows (do not copy real descriptions).
User message: compact table of rows {index,date,description,reference,debit,credit}. Batch size 20 rows per call (2 calls total) to stay inside free-tier limits.
validate.ts: validateCategorization(rows, llmOut): returns issues[]:
 - indexes complete and unique; direction rules (capital_call/dividend/interest/sale_proceeds/expense_refund must be credit; distribution/management_fee/purchase/bank_charges/expense/accrual_settlement must be debit);
 - lp_code required for capital_call/distribution and must exist in the roster; company required for purchase/sale, forbidden otherwise;
 - accrual_settlement amount must equal a Q3 liability amount.
Tests: validators catch each violation with a clear message.
```
### PROMPT 7-B — Fallback + orchestration
```
[paste CONVENTIONS]

Write src/agentA/llm/fallback.ts: rulesCategorize(row, ctx{lpRoster, q3Liabilities}) — deterministic regex/keyword rules mirroring the prompt rules (no company names hardcoded: derive company for purchase/sale by stripping known prefixes like "OUTWARD WIRE"/"INWARD WIRE" and trailing words like "SUBSCRIPTION ...", "COMPLETION", "SPA"; for sale with a buyer, take the entity before/after "COMPLETION" as the sold company; if ambiguous leave company null and let validation fail loudly).
 LP resolution: code regex /\bLP\d{2}\b/ else fuzzy name match to roster (normalise: uppercase, strip punctuation, token overlap >= 0.6, e.g. "R MEHTA FAM TRST" ↔ "R. Mehta Family Trust" via prefix-token matching).
Write src/agentA/llm/categorize.ts: categorizeAll(rows, deps{llm, ctx, logger}) -> Categorized[] with {category, lp_code, company, categorized_by}.
 Flow: LLM batches -> validate -> for rows with issues re-ask LLM once (only those rows, include the issue text) -> still invalid or LLM threw LlmError -> rulesCategorize for those rows, categorized_by:"rules_fallback", log WARN. After everything, run validate again; if still invalid throw ValidationError (never emit inconsistent data).
 Also post-fix deterministic LP resolution: if category is capital_call/distribution and lp_code is null, resolve by roster fuzzy match.
Tests (offline, fake LlmClient): perfect LLM -> all "llm"; LLM wrong on 2 rows -> corrected via re-ask; LLM always throws -> all rows from fallback and golden labels still match.
```
### PROMPT 7-C — Golden labels + live check script
```
[paste CONVENTIONS]

Create tests/fixtures/expected_categories.json (39 entries in statement order) with {category, lp_code, company}:
 order: management_fee; accrual_settlement(admin 65,000); dividend_income; accrual_settlement(audit 120,000);
 capital_call LP02; capital_call LP01; interest_income; capital_call LP07; capital_call LP04; capital_call LP03; capital_call LP05;
 bank_charges; bank_charges; capital_call LP08; capital_call LP06; capital_call LP09; capital_call LP07; expense (legal);
 capital_call LP10; sale_proceeds company "Fjord Payments AS"; expense_refund; interest_income; bank_charges;
 distribution x10 in this LP order: LP07, LP09, LP02, LP04, LP01, LP08, LP06, LP10, LP03, LP05; bank_charges (30 Nov wire charges);
 expense (D&O); investment_purchase company "Ionmere Materials Ltd"; interest_income; bank_charges; bank_charges.
Assert the fallback categorizer reproduces ALL 39 offline (tests/unit/fallback.golden.test.ts). This is your safety net AND your regression test.
Write scripts/llm-live-check.ts (opt-in, uses real env): parse the real PDF, run categorizeAll with the real LlmClient, print a table row | expected | got | by, and exit 1 on any mismatch. Prints how many rows came from fallback.
```
### ✅ MODULE 7 TEST
```bash
npm test -- fallback categorize validate
npm run llm:check   # live, 2 LLM calls. Expect 39/39 match, 0 fallback rows.
```

---

## MODULE 8 — Trades derivation + Agent A
> Goal: Agent A is a standalone A2A server + a `runAgentA(client)` use-case.

### PROMPT 8-A — trades.ts + transactions writer shape
```
[paste CONVENTIONS]

Write src/agentA/trades.ts: deriveTrades(categorized: Categorized[]): {purchases: {company,date,amount_usd:number}[], sales: {company,date,proceeds_usd:number}[]}.
 purchases = rows category investment_purchase (amount = debit); sales = sale_proceeds (amount = credit). Amounts via toNumber2. Sorted by date. Company required (throw ValidationError if null).
Also write src/agentA/toTransactions.ts mapping rows to the output shape: {date, description, reference, debit, credit, balance, category, lp_code, company, categorized_by} (numbers via toNumber2; reference "" -> keep "" ; lp_code/company null when n/a).
Tests: golden fixture -> purchases = [Ionmere 2022-12-15 14000000], sales = [Fjord 2022-11-18 29000000].
```
### PROMPT 8-B — Agent A as A2A server
```
[paste CONVENTIONS]

Agent A is a CLIENT of Agent B in the brief, but it must ALSO expose an agent card + message/send endpoint.
Write src/agentA/index.ts: createAgentA(deps) -> {app, ingest(): Promise<IngestResult>}.
 - ingest(): read PDF from PACK_DIR (pattern /Bank_Statement/), extractLines -> parseStatement -> runBankChecks (assert) -> categorizeAll -> IngestResult {transactions, bankReport, trades}. Cache the result in memory (idempotent).
 - A2A card: name "GPF Bank & Ingestion Agent", skill "bank-statement-ingestion".
 - handler: message/send with a text/data part {"action":"get_trades"} returns a completed Task whose artifact holds {purchases, sales, transaction_count}. (Gives us a real, testable endpoint for Agent A, separate from the A→B flow.) Unknown action -> failed task with message.
 Agent A imports NOTHING from src/agentB or pack/loadAgentBData. LP roster + Q3 liabilities come from pack/loadNavSummary (read-only reference data) — record this as an assumption in ASSUMPTIONS.md.
Write src/agentA/executor.ts: runBankAgent({ingest, bClient, logger}): performs the 2-turn conversation:
 1. send {fund:"GPF", valuation_date:"2022-12-31"} data part (read fund code + date from args/config, not literals in executor).
 2. expect Task.status.state === "input-required"; keep id + contextId.
 3. send second message with taskId+contextId and data {purchases, sales}.
 4. if completed -> return artifacts[0] data part UNCHANGED. If input-required again, read the matched count from the status message, log it, retry up to 3 total attempts (re-run deriveTrades; do NOT mutate amounts to make them match), then throw A2AError with a clear message.
Tests (integration, fake B handler on port 0): happy path; B reports "1 of 2 matched" -> 3 attempts then error; B returns failed -> error.
```
### ✅ MODULE 8 TEST
```bash
npm test -- agentA trades
# Plus real-file integration: ingest() over pack/ with the fake LlmClient/fallback gives 39 transactions and golden trades.
```

---

## MODULE 9 — Review engine (Agent B)
### PROMPT 9-A — review.ts (pure)
```
[paste CONVENTIONS]

Write src/agentB/review.ts: reviewMarks(input): ReviewResult, pure, no IO.
input = {q3: Q3Position[], q4Marks: Mark[], heldAtQ4: Set<string> (names), purchases, sales, fxRate: string (EURUSD), thresholdPct: Decimal}.
Company matching uses normalizeName() (lowercase, strip punctuation, collapse spaces) — put in src/core/names.ts, reused by trade verification.
Per company in union(Q3, Q4 marks, purchases):
 - R1: |pctChange(q3 local FV, q4 local FV)| >= threshold. Measured in LOCAL currency. Also output change_pct_usd for information only (not used for flagging).
 - R2: both methods exist and differ (case-insensitive trim).
 - R3: held at Q4 (in Q3 and not sold, or purchased in Q4) AND no Q4 mark -> flag, valuation carried at cost (USD purchase amount, or Q3 cost for a continuing holding).
 - R4: Q4 mark exists but company not held at Q4 (sold, or never held) -> flag, excluded from NAV.
 - sold company with no mark -> flags [] and reason "Sold <date>; realized, excluded from NAV".
Output entry exactly: {company, currency, q3_fair_value, q4_fair_value, change_pct, q3_method, q4_method, flags[], reason}; q3/q4 values in LOCAL currency as numbers (null when absent); change_pct rounded to 2 dp number or null; reason = one line joining human sentences for each flag (e.g. "Mark up 37.50% in USD vs 15% threshold (R1)"). Top level: {threshold_pct, eurusd_rate, entries[]}.
 eurusd_rate output as number 1.0666.
Do not hardcode names. Tests (tests/unit/review.test.ts) with real loaders: flags = Bluetarn R1, Cedar R1, Harbor R1, Delta R2, Ionmere R3, Ember none (change −2.96, even though USD change +6.17), Fjord none. Boundary tests: exactly 15.00% flags; 14.99% does not. R4 with a synthetic extra mark flags and is excluded.
```
### ✅ MODULE 9 TEST
```bash
npm test -- review
```

---

## MODULE 10 — NAV engine (Agent B)
### PROMPT 10-A — nav.ts (pure)
```
[paste CONVENTIONS]

Write src/agentB/nav.ts: computeNav(input): NavResult, pure.
input = {closingCash, navQ3, q3Holdings: Q3Holding[] (cost, FV USD), q4Marks, fx, review (flags), purchases, sales, q4Accruals: Liability[], transactions: categorized rows}.
Steps:
 1. Q4 positions held = (Q3 holdings − sold companies) ∪ purchased companies.
 2. Q4 FV USD: mark in USD as is; EUR via mulRate(local, fx.EUR) ; R3 company -> carried at cost; R4 company excluded.
    Cost stays as given in USD (Ember 14,184,000 — never re-converted); purchase cost = purchase amount.
 3. investments_usd = Σ FV; liabilities = Σ q4Accruals; nav_q4 = closing_cash + investments_usd − liabilities.
 4. Bridge: capital_called = Σ capital_call credits; distributions = Σ distribution debits; income = dividend_income + interest_income;
    expenses = management_fee + expense + bank_charges − expense_refund + Σ q4Accruals (accrual_settlement excluded!);
    realized_gain = Σ sale proceeds − cost of sold stake (cost from Q3 holdings);
    change_in_unrealized = Σ(FV−cost at Q4 held) − Σ(FV−cost at Q3 all holdings incl. the sold one);
    bridge.nav_q4 = nav_q3 + capital_called − distributions + income − expenses + realized_gain + change_in_unrealized; difference = nav_q4 − bridge.nav_q4 (must be 0.00).
 5. Also output management_fee separately (form needs it) and an `expense_breakdown`.
Output shape: {closing_cash, investments_usd, liabilities, nav_q4, management_fee, bridge:{nav_q3,capital_called,distributions,income,expenses,realized_gain,change_in_unrealized,nav_q4,difference}} numbers via toNumber2.
If difference != 0 throw ReconciliationError naming the delta — "fix the cause, not the number": the error message should hint to check categories (e.g. an accrual_settlement counted as expense).
Tests (golden): every number in the Ground Truth table; swapping one accrual_settlement to expense makes difference = 65,000 and throws; fx 1.0667 changes NAV by exactly 1,310.00; sale of a stake not in Q3 holdings throws.
```
### ✅ MODULE 10 TEST
```bash
npm test -- nav
# nav_q4 must equal 169764039.25 and difference 0
```

---

## MODULE 11 — Agent B server (two-turn state machine)
### PROMPT 11-A — verifyTrades + marks artifact
```
[paste CONVENTIONS]

Write src/agentB/verifyTrades.ts: verifyTrades(claimed, records): {matched: number, expected: number, ok: boolean}. Items match when normalizeName(company), date and amount in CENTS all equal (amount_usd/proceeds_usd may be number or string). Duplicates must not double-match (consume matches). ok only if all expected matched AND no extra claimed items. Empty lists vs empty records -> ok.
Write src/agentB/marks.ts: buildMarksArtifact(agentBData): {fund: fundName, valuation_date, marks:[{company,currency,fair_value:number,valuation_method,valuation_date}], notes} — fair_value converted from string via decimal then toNumber2. Artifact id "marks-GPF-2022-12-31" built from fund code + date.
Tests: exact match ok; wrong amount 1 of 2; extra claimed item not ok; string vs number amounts.
```
### PROMPT 11-B — Agent B server
```
[paste CONVENTIONS]

Write src/agentB/index.ts: createAgentB({pack, taskStore, fx, thresholdPct}) -> {app, getResults()}.
Card: name "GPF Valuation & NAV Agent", skill "valuation-and-nav".
Handler state machine (TaskStore keyed by task id):
 - Message without taskId: require data part {fund, valuation_date}; validate fund code & date against agent_b_data (mismatch -> failed task). Create task + contextId (uuid), state "input-required", status.message text part: "To release the Q4 marks I need the fund's Q4 purchases and sales of companies. Send a data part {purchases:[{company,date,amount_usd}], sales:[{company,date,proceeds_usd}]}."
 - Message with taskId+contextId: unknown id -> JSON-RPC TaskNotFound (-32001); contextId mismatch -> InvalidParams; already completed -> return the completed task again (idempotent). Validate data part with zod. verifyTrades: ok -> state "completed", artifacts[0] = marks artifact (data part). Not ok -> stay "input-required", status.message "Matched N of M items. Please re-check your purchases and sales and resend."
 - After a task completes, the marks are released. Review + NAV are computed by `agentB.computeReports({transactions, bankReport})`, called by the orchestrator (Module 12) with Agent A's output, because the brief's A2A messages carry only purchases/sales. Record this in DECISIONS.md. computeReports runs reviewMarks + computeNav using ONLY verified trades, and stores the result for getResults().
Keep the A2A message contract EXACTLY as the brief (kind/role/messageId/taskId/contextId/parts). Nothing extra required of Agent A.
Tests (integration, port 0, real pack): full 2-turn happy path; wrong amounts -> input-required "Matched 1 of 2"; empty lists when records exist -> not ok; unknown taskId -> -32001; first message missing data -> -32602; completed task resend is idempotent; artifact fair_value are numbers and notes preserved.
```
### ✅ MODULE 11 TEST
```bash
npm test -- agentB
```

---

## MODULE 12 — Orchestrator + output files
### PROMPT 12-A — writers
```
[paste CONVENTIONS]

Write src/output/writers.ts: writeOutputs(dir, {transactions, marksArtifact, review, nav, bankReport}).
 - transactions.json (array, spec fields + categorized_by), marks.json = the artifact data received by Agent A, written from the raw received object with NO transformation, review.json, nav.json, bank_checks.json. Pretty-print 2 spaces. Delete stale files in OUTPUT_DIR first (graders delete output/ and compare).
 - a2a_log.jsonl is written live by the client log (Module 2-D); writer only ensures dir exists.
Deterministic output: sorted keys not required, but no timestamps in the JSON files other than a2a_log.jsonl (so two runs diff clean).
```
### PROMPT 12-B — main.ts
```
[paste CONVENTIONS]

Write src/main.ts — the ONE command: `npm start -- ./pack .`  (argv[2]=packDir default ./pack from PACK_DIR/default; argv[3]=working root, output goes to <root>/output; document in README).
Flow:
 1. env + fx + loaders. Fail fast with readable errors (missing key etc.).
 2. Start Agent B (port AGENT_B_PORT) and Agent A (AGENT_A_PORT) in-process with Express listen; ports of 0 allowed for tests.
 3. Agent A: ingest() (parse, checks, categorize). Run runBankAgent with A2AClient(http://127.0.0.1:BPORT) and shared jsonl log -> artifact.
 4. agentB.computeReports({transactions, bankReport}) -> review, nav.
 5. writeOutputs. Print a concise summary table (cash, investments, liabilities, NAV, flags, threshold, fx, txn count, #rows from fallback).
 6. Always shut both servers down in `finally`; exit code 0 on success, 1 on error with one-line message; unhandled rejection handler.
Keep main.ts under ~80 lines by delegating to a `runPipeline(deps)` in src/pipeline.ts so tests can run it with fake LLM and ephemeral ports.
Tests (tests/integration/pipeline.test.ts): run pipeline with LLM stub that throws (forces fallback), temp output dir; assert every file exists, nav_q4 169764039.25, difference 0, transactions.length 39, a2a_log.jsonl has 4 lines pairs (>=4 entries) each with ts, marks.json deep-equals the artifact data, two consecutive runs produce byte-identical JSON (except log).
```
### ✅ MODULE 12 TEST
```bash
npm test -- pipeline
npm start -- ./pack .        # real LLM, real run
ls output/                   # transactions.json a2a_log.jsonl marks.json review.json nav.json bank_checks.json
node -e "const n=require('./output/nav.json');console.log(n.nav_q4,n.bridge.difference)"
# 169764039.25 0
```

---

## MODULE 13 — Endpoint smoke script
> Your "is any endpoint failing?" button. Boots both agents offline (stub LLM) on ephemeral ports and prints a PASS/FAIL table.

### PROMPT 13-A — scripts/smoke.ts
```
[paste CONVENTIONS]

Write scripts/smoke.ts (run: npm run smoke). It must NOT call any real LLM (use rules fallback / stub) and must exit 1 if any check fails.
Checks (each prints ✅/❌ with ms):
 Agent A
  1 GET /.well-known/agent-card.json -> 200, protocolVersion "0.3.0", url present
  2 POST message/send {"action":"get_trades"} -> completed task with 1 purchase + 1 sale + transaction_count 39
  3 invalid JSON body -> -32700 ; 4 wrong method -> -32601 ; 5 bad params -> -32602
 Agent B
  6 card OK
  7 first message -> input-required with taskId+contextId
  8 second message with WRONG amounts -> input-required + "Matched 1 of 2"
  9 second message correct -> completed, artifacts[0] has 7 marks + 2 notes, fair_value numeric
  10 re-send after completion -> same completed task (idempotent)
  11 unknown taskId -> -32001 ; 12 missing data part -> -32602
 Pipeline
  13 runPipeline to a temp dir -> all output files exist, nav difference 0.00, nav_q4 == 169764039.25
 Print summary "12/13 passed" and a non-zero exit code on any failure.
Use a tiny helper rpc(url, method, params) with fetch; no extra dependencies.
```
### ✅ MODULE 13 TEST
```bash
npm run smoke
# Expect 13/13. Any ❌ names the failing endpoint.
```

---

## MODULE 14 — Docs, packaging, dry run
### PROMPT 14-A — ASSUMPTIONS.md (use the provided template format)
```
Write ASSUMPTIONS.md using the template format (## Assumption N: / **What I assumed:** / **Why:** / **What would change if wrong:**). Include at least:
1. FX rate and date: EUR/USD 1.0666 = ECB reference rate 30 Dec 2022 (last published on/before Sat 31 Dec; same convention as CVP's Q3 0.9748 on 30 Sep 2022). Source URL. If wrong: each 0.0001 moves NAV by 1,310.00 (EUR 13.1M × 0.0001); using the 3 Jan 2023 rate instead would change Ember and NAV accordingly.
2. Materiality: 15 %, absolute change in LOCAL currency, inclusive (>=). Ember −2.96% local / +6.17% USD shows why local currency. If wrong: at 20 % Harbor (+17.83 %) drops out; at 10 % same three flagged; at 25 % Bluetarn and Cedar only.
3. Company with no mark (Ionmere): carried at cost USD 14,000,000 until first valuation; R3 flagged. If wrong (left out): NAV lower by 14,000,000 and unrealized change lower by 0 (cost = value).
4. Agent A reads the LP roster and Q3 liabilities from the pack's NAV summary as read-only reference data (needed to resolve LP10 and recognise accrual settlements); it never reads agent_b_data.json.
5. D&O premium for 2023 expensed fully in Q4 (per the brief); bank charges are expenses; Harbourside 65,000 and Coral & Finch 120,000 are accrual_settlements, not expenses.
6. Fjord (sold) gets a review entry with no flags; transactions.json excludes the opening-balance line (39 rows).
Fill numbers from your actual output files, not from this guide.
```
### PROMPT 14-B — DECISIONS.md + README.md
```
DECISIONS.md (3+ decisions, template format): (1) hand-rolled A2A 0.3 on Express+zod vs @a2a-js/sdk 1.x (spec mismatch, control, testability); (2) deterministic PDF parsing + LLM only for categorization, validated in code with rules fallback; (3) decimal.js everywhere / bridge must balance or the run fails; optionally (4) Agent B computes NAV in-process from Agent A's output because the A2A contract only carries trades.
README.md: what it is; requirements (Node >=22.13, tested on 24); setup `npm install`, copy .env.example to .env; run `npm start -- ./pack .` (args: packDir, root; output in ./output); tests `npm test` (offline), `npm run smoke`, `npm run llm:check`; architecture diagram (ASCII) of Agent A / A2A / Agent B; env vars; honest gaps (no streaming/push, in-memory task store, single fund hard-wired to one statement format, fallback rules are heuristic, no auth on A2A endpoints, LLM free-tier limits, ECB rate hard-coded from a cited source); next steps to production (official A2A SDK, persistent task store, auth/mTLS, OpenTelemetry, idempotency keys, multi-fund config, bank-format adapters, human review UI). State plainly: Node/TypeScript instead of the brief's Python (emailed before 14:00 IST).
```
### PROMPT 14-C — Packaging dry run
```
Create scripts/package.sh (bash) that builds the submission zip: include src, tests, scripts, config, pack, output, docs, package.json, package-lock.json, tsconfig.json, vitest.config.ts, .env.example. Exclude node_modules, .git, .env, .cache, .vitest, coverage. Print zip size (must be < 10 MB).
Then do a CLEAN-CLONE DRY RUN: unzip to a temp folder, `npm ci`, copy .env, `npm test`, `rm -rf output`, `npm start -- ./pack .`, and diff the new output/*.json against the originals (only a2a_log.jsonl timestamps may differ).
```
### ✅ FINAL CHECKLIST (one submission only!)
```bash
npm run typecheck && npm test && npm run smoke && npm start -- ./pack .
grep -rn "sk-\|api_key\|OPENROUTER" src/ README.md   # nothing secret, no OPENROUTER usage
```
- [ ] Form numbers copied from `output/nav.json` / `review.json` (closing_cash 23896579.25, capital_called 20000000.00, distributions 22500000.00, management_fee 1250000.00, income 459429.25, expenses 1522850.00, realized_gain 9000000.00, change_in_unrealized 4102660.00, investments 146062460.00, NAV 169764039.25, EUR/USD 1.0666, threshold 15, flagged: Bluetarn, Cedar, Harbor, Delta, Ionmere, transactions 39) — **only if your output files show the same**
- [ ] ECB rate page opened and confirmed; source cited in ASSUMPTIONS.md
- [ ] `output/` present in zip, no `.env`, zip < 10 MB
- [ ] Recording 60–90 s: run `npm start -- ./pack .`, then explain one decision (suggest: R1 measured in local currency, Ember example)
- [ ] Declared AI tools + LLM used (Claude / your IDE agent, OpenRouter model name), hours spent

## Time plan (now → 18:00 IST, leave 30 min buffer)
| Block | Modules |
|---|---|
| 12:15–13:00 | 0, 1 |
| 13:00–13:40 | 2, 3 |
| 13:40–14:40 | 4, 5 (hardest; golden = 39 rows) |
| 14:40–15:30 | 6, 7 |
| 15:30–16:15 | 8, 11 |
| 16:15–16:50 | 9, 10 |
| 16:50–17:15 | 12, 13 |
| 17:15–17:45 | 14, dry run, record, submit |

**If behind:** cut in this order — LLM disk cache, `llm:check`, bank_checks.json extras, smoke checks 10–12. Never cut: balance chain check, bridge difference check, README gaps, ASSUMPTIONS.